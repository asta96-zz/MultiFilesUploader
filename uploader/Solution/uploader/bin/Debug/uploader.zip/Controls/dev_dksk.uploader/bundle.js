var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./uploader2/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./uploader2/index.ts":
/*!****************************!*\
  !*** ./uploader2/index.ts ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.uploader = void 0;\n\nvar EntityReference =\n/** @class */\nfunction () {\n  // id: string;\n  // typeName: string;\n  function EntityReference(typeName, id) {\n    this.typeName = typeName;\n    this.id = id; // this.id = id;\n    // this.typeName = typeName;\n  }\n\n  return EntityReference;\n}();\n\nvar AttachedFile =\n/** @class */\nfunction () {\n  function AttachedFile(annotationId, fileName, mimeType, fileContent, fileSize) {\n    this.annotationId = annotationId;\n    this.fileName = fileName;\n    this.mimeType = mimeType;\n    this.fileContent = fileContent;\n    this.fileSize = fileSize;\n  }\n\n  return AttachedFile;\n}();\n\nvar uploader =\n/** @class */\nfunction () {\n  function uploader() {\n    var _this = this;\n\n    this.Files = [];\n\n    this.CreateFormUploadDiv = function () {\n      var UploadForm = document.createElement(\"div\");\n      var UploadLabel = document.createElement(\"label\");\n      UploadLabel.htmlFor = \"file-upload\";\n      UploadLabel.id = \"lbl-file-upload\";\n      UploadLabel.innerText = \"Choose Files to Upload\";\n      var UploadInput = document.createElement(\"input\");\n      UploadInput.id = \"file-upload\";\n      UploadInput.type = \"file\";\n      UploadInput.multiple = true;\n      UploadInput.addEventListener(\"change\", _this.handleBrowse);\n      var DragDiv = document.createElement(\"Div\");\n      DragDiv.id = \"watermarkdiv\";\n      DragDiv.className = \"watermarkdiv\";\n      DragDiv.innerText = \"or drop files here...\";\n      var catchedfileslist = document.createElement(\"ol\");\n      catchedfileslist.id = \"catchedfileslist\";\n\n      var fileCatcher = _this.createDiv(\"files-catcher\", \"files\", [catchedfileslist]);\n\n      var filesHolder = _this.createDiv(\"file-holder\", \"\", [DragDiv, fileCatcher]);\n\n      var UploadButton = document.createElement(\"button\");\n      UploadButton.innerText = \"Upload\";\n      UploadButton.className = \"buttons\";\n      UploadButton.addEventListener(\"click\", _this.handleUpload);\n      var ClearButton = document.createElement(\"button\");\n      ClearButton.innerText = \"Reset\";\n      ClearButton.className = \"buttons\";\n      ClearButton.addEventListener(\"click\", _this.handleReset);\n\n      var leftDiv = _this.createDiv(\"left-container\", \"left-container\", [UploadLabel, UploadInput, UploadButton, ClearButton]);\n\n      var rightDiv = _this.createDiv(\"right-container\", \"right-container\", [filesHolder]);\n\n      rightDiv.addEventListener(\"dragover\", _this.FileDragHover);\n      rightDiv.addEventListener(\"dragleave\", _this.FileDragHover);\n      rightDiv.addEventListener(\"drop\", _this.handleBrowse);\n\n      var mainContainer = _this.createDiv(\"main-container\", \"main-container\", [leftDiv, rightDiv]);\n\n      UploadForm.appendChild(mainContainer); // UploadForm.appendChild(UploadLabel);\n      // UploadForm.appendChild(UploadInput);\n      // UploadForm.appendChild(DragDiv);\n      // UploadForm.appendChild(UploadButton);\n      // UploadForm.appendChild(ClearButton);\n\n      return UploadForm;\n    }; //\n\n\n    this.handleBrowse = function (e) {\n      e.preventDefault();\n      console.log(\"handleBrowse\");\n      console.log(e);\n      var files = e.target.files || e.dataTransfer.files;\n\n      if (files.length > 0) {\n        _this.addFiles(files);\n      }\n    }; //handles post call to CRM\n\n\n    this.handleUpload = function (e) {\n      debugger;\n      console.log(\"handleUpload\");\n      console.log(e);\n      var files = _this.Files;\n      var valid = files && files.length > 0;\n\n      if (!valid) {\n        alert(\"Please select a file!\");\n        return;\n      } else {\n        for (var i = 0; i < files.length; i++) {\n          var file = files ? files[i].file : \"\";\n\n          if (file !== \"\") {\n            _this.toBase64String(file, function (file, text) {\n              var type = file.type; // this.renderToPlayer(text, type);\n\n              var notesEntity = new AttachedFile(\"\", file.name, type, text, file.size);\n\n              _this.addAttachments(notesEntity);\n            });\n          }\n        }\n\n        debugger;\n        alert(\"uploaded \" + files.length + \" number of files as attachments\");\n\n        _this.clearAttachments();\n      }\n    };\n\n    this.clearAttachments = function () {\n      var fileList = document.getElementById(\"catchedfileslist\");\n\n      if (fileList) {\n        while (fileList.hasChildNodes()) {\n          fileList.removeChild(fileList.firstChild);\n        }\n      }\n\n      _this.Files = [];\n      _this.$id(\"watermarkdiv\").style.display = \"block\";\n    };\n\n    this.addAttachments = function (file) {\n      debugger;\n      var notesEntity = {};\n      console.log(file);\n      var fileContent = file.fileContent;\n      fileContent = fileContent.substring(fileContent.indexOf(\",\") + 1, fileContent.length);\n      notesEntity[\"documentbody\"] = fileContent;\n      notesEntity[\"filename\"] = file.fileName;\n      notesEntity[\"filesize\"] = file.fileSize;\n      notesEntity[\"mimetype\"] = file.mimeType;\n      notesEntity[\"subject\"] = file.fileName;\n      notesEntity[\"notetext\"] = \"Attachments uploaded via PCF uploader\";\n      notesEntity[\"objecttypecode\"] = _this.entityReference.typeName;\n      notesEntity[\"objectid_\" + _this.entityReference.typeName + \"@odata.bind\"] = \"/\" + _this.CollectionNameFromLogicalName(_this.entityReference.typeName) + \"(\" + _this.entityReference.id + \")\";\n      var thisRef = _this; // Invoke the Web API to creat the new record\n\n      _this._context.webAPI.createRecord(\"annotation\", notesEntity).then(function (response) {\n        // Callback method for successful creation of new record\n        console.log(response); // Get the ID of the new record created\n\n        notesEntity[\"annotationId\"] = response.id;\n        notesEntity[\"fileContent\"] = file.fileContent;\n        notesEntity[\"fileName\"] = notesEntity[\"filename\"]; //this.renderToPlayer(file.fileContent, file.mimeType);\n\n        console.log(\"Uploaded !!\" + file.fileName);\n      }, function (errorResponse) {\n        // Error handling code here - record failed to be created\n        console.log(errorResponse);\n        alert(\"Unable to uploaded video!!\");\n      });\n    };\n\n    this.CollectionNameFromLogicalName = function (entityLogicalName) {\n      if (entityLogicalName[entityLogicalName.length - 1] != \"s\") {\n        return entityLogicalName + \"s\";\n      } else {\n        return entityLogicalName + \"ies\";\n      }\n    };\n\n    this.toBase64String = function (file, successFn) {\n      var reader = new FileReader();\n      reader.readAsDataURL(file);\n\n      reader.onload = function () {\n        return successFn(file, reader.result);\n      };\n\n      console.log(reader.result);\n      return reader.result;\n    };\n\n    this.$id = function (id) {\n      return document.getElementById(id);\n    }; //handles clearing all the uploaded files\n\n\n    this.handleReset = function (e) {\n      console.log(\"handleReset\");\n      console.log(e);\n\n      _this.clearAttachments();\n    };\n\n    this.FileDragHover = function (e) {\n      e.stopPropagation();\n      e.preventDefault(); // e.target.className = e.type == \"dragover\" ? \"hover\" : \"\";\n\n      console.log(\"dragover\", e);\n    };\n  }\n\n  uploader.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this.Files = [];\n    this._context = context;\n    this.entityReference = new EntityReference(context.page.entityTypeName, context.page.entityId);\n    var UploadForm = this.CreateFormUploadDiv();\n    container.appendChild(UploadForm);\n  };\n\n  uploader.prototype.createDiv = function (divid, classname, childElements) {\n    if (classname === void 0) {\n      classname = \"\";\n    }\n\n    var _div = document.createElement(\"div\");\n\n    _div.id = divid;\n    classname ? _div.className = classname : \"\";\n\n    if (childElements != null && (childElements === null || childElements === void 0 ? void 0 : childElements.length) > 0) {\n      childElements.forEach(function (child) {\n        _div.appendChild(child);\n      });\n    } // return crLableNInput();\n\n\n    return _div;\n  };\n\n  uploader.prototype.addFiles = function (files) {\n    var counter = this.Files.length;\n\n    if (counter > 0 || files.length > 0) {\n      var filesDiv = this.$id(\"watermarkdiv\");\n      filesDiv.style.display = \"none\";\n    }\n\n    var fileList = this.$id(\"catchedfileslist\");\n\n    for (var i = 0; i < files.length; i++) {\n      counter++;\n      var nodetype = {};\n      nodetype.id = \"progress\" + counter;\n      nodetype.file = files[i];\n      var fileNode = document.createElement(\"li\");\n      var text = document.createTextNode(files[i].name);\n      fileNode.appendChild(text);\n      fileList.appendChild(fileNode); //fileNode.className = \"individual-file\";\n      //this.$id(\"files-catcher\").appendChild(fileNode);\n\n      this.Files[this.Files.length] = nodetype;\n    }\n  };\n\n  uploader.prototype.updateView = function (context) {// Add code to update control view\n  };\n\n  uploader.prototype.getOutputs = function () {\n    return {};\n  };\n\n  uploader.prototype.destroy = function () {};\n\n  return uploader;\n}();\n\nexports.uploader = uploader;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./uploader2/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('dksk.uploader', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.uploader);
} else {
	var dksk = dksk || {};
	dksk.uploader = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.uploader;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}